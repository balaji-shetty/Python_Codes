for i in range(3):
    print(i)

print("First Student:")
a = int(input("Enter Pen:"))
b =int(input("Enter Pencil:"))
c = int(input("Enter Notebook:"))
t = a+b+c
print(t)

print("Second Student:")
a = int(input("Enter Pen:"))
b =int(input("Enter Pencil:"))
c = int(input("Enter Notebook:"))
t = a+b+c
print(t)

print("Third Student:")
a = int(input("Enter Pen:"))
b =int(input("Enter Pencil:"))
c = int(input("Enter Notebook:"))
t = a+b+c
print(t)



for i in range(3):
    a = int(input("Enter Pen:"))
    b =int(input("Enter Pencil:"))
    c = int(input("Enter Notebook:"))
    t = a+b+c
    print(t)
