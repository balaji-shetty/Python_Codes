# Program to add 4 students marks using variables

Physics = int(input(" Enter Physics:"))
Chemistry =int(input("Enter Chemistry:"))
Math = int(input("Enter Math:"))
t = Physics + Chemistry + Math
print(t)

Physics = int(input(" Enter Physics:"))
Chemistry =int(input("Enter Chemistry:"))
Math = int(input("Enter Math:"))
t = Physics + Chemistry + Math
print(t)

Physics = int(input(" Enter Physics:"))
Chemistry =int(input("Enter Chemistry:"))
Math = int(input("Enter Math:"))
t = Physics + Chemistry + Math
print(t)

Physics = int(input(" Enter Physics:"))
Chemistry =int(input("Enter Chemistry:"))
Math = int(input("Enter Math:"))
t = Physics + Chemistry + Math
print(t)

