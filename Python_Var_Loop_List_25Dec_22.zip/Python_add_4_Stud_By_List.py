Physics = []
Chemistry = []
Math = []
total = []

for i in range(4):
    Physics.append(int(input("Enter Physics:")))
    Chemistry.append(int(input("Enter Chemistry:")))
    Math.append(int(input("Enter Math:")))

    total.append(Physics[i]+Chemistry[i]+Math[i])
    print("Total array is ",total)

for i in range(4):
    print("Physics Marls is ",Physics[i])

for i in range(4):
    print("Chemistry Marks is ",Chemistry[i])

for i in range(4):
    print("Math Marks is ",Math[i])

for i in range(4):
    print("Avg Marks is ",total[i]/3)
