Pen = int(input(" Enter Pen:"))
Pencil =int(input("Enter Pencil:"))
Notebook = int(input("Enter Notebook:"))
t = Pen +Pencil + Notebook
print(t)


Pen = int(input("Enter Pen"))
Pencil =int(input("Enter Pencil"))
Notebook = int(input("Enter Notebook"))
t = Pen +Pencil + Notebook
print(t)

Pen = int(input("Enter Pen"))
Pencil =int(input("Enter Pencil"))
Notebook = int(input("Enter Notebook"))
t = Pen +Pencil + Notebook
print(t)

Pen = int(input("Enter Pen"))
Pencil =int(input("Enter Pencil"))
Notebook = int(input("Enter Notebook"))
t = Pen +Pencil + Notebook
print(t)

