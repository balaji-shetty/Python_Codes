# Program to add 4 students marks using Loop
for i in range(4):
    print(i)

for i in range(4):
    print("HELLO- Loop i:",i)

for i in range(10):
    print("HELLO- Loop i:",i)

print("\n")

for j in range(4):
    print("Loop j, Statement 1  j=", j)
    print("Loop j, Statement 2  j=", j)
    
print("\n")
    
for i in range(4):
    Physics = int(input(" Enter Physics:"))
    Chemistry =int(input("Enter Chemistry:"))
    Math = int(input("Enter Math:"))
    t = Physics + Chemistry + Math
    print(t)


print("Physics:",Physics, " Chemistry:",Chemistry, " Math:",Math)    

for i in range(4):
    print("Physics:",Physics, " Chemistry:",Chemistry, " Math:",Math)
    
