a = []
b = []
c = []
t = []

for i in range(4):
    a.append(int(input("Enter Pen")))
    b.append(int(input("Enter Pencil")))
    c.append(int(input("Enter Notebook")))

    t.append(a[i]+b[i]+c[i])
    print(t)


for i in range(3):
    for j in range(3):
        print("i=",i,"  j= ",j)     
    



for i in range(3):
    for j in range(3):
        for k in range(3):
            print("i=",i,"  j= ",j," k=",k)     
    
