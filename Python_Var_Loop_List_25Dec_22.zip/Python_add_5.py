a = int(input("Enter Pen"))

b =int(input("Enter Pencil"))
c = int(input("Enter Notebook"))

t = a+b+c
print(t)


a = int(input("Enter Pen"))

b =int(input("Enter Pencil"))
c = int(input("Enter Notebook"))

t = a+b+c
print(t)

a = int(input("Enter Pen"))

b =int(input("Enter Pencil"))
c = int(input("Enter Notebook"))

t = a+b+c
print(t)

a = int(input("Enter Pen"))

b =int(input("Enter Pencil"))
c = int(input("Enter Notebook"))

t = a+b+c
print(t)

a = int(input("Enter Pen"))

b =int(input("Enter Pencil"))
c = int(input("Enter Notebook"))

t = a+b+c
print(t)
