Physics = []
Chemistry = []
Math = []
total = []

for i in range(4):
    Physics.append(int(input("Enter Physics:")))
    Chemistry.append(int(input("Enter Chemistry:")))
    Math.append(int(input("Enter Math:")))

    total.append(Physics[i]+Chemistry[i]+Math[i])
    print("Total array is ",total)

for i in range(4):
    print("Total Marks is ",total[i])
